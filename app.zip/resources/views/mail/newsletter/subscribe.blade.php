@component('mail::message')
# Newsletter

Thank you for subscribing to our Newsletter.

Regards,<br>
{{ config('app.name') }}
@endcomponent
